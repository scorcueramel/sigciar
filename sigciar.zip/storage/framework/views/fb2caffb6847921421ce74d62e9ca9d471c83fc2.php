<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('assets/template/css/core.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/template/css/theme-default.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/template/css/demo.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/template/css/perfect-scrollbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/template/css/')); ?>">
</head>
<body class="antialiased">

    <?php echo $__env->yieldContent('content'); ?>

    <script src="<?php echo e(asset('assets/js/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/template/js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/template/js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/template/js/perfect-scrollbar.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/template/js/menu.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\sigciar\resources\views/errors/template-error.blade.php ENDPATH**/ ?>