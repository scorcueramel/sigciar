<!-- Modal -->
<div class="modal fade" id="modalcomponent" tabindex="-1" aria-labelledby="mcLabel" aria-hidden="true">
    <div class="modal-dialog <?php echo e($tamanio ?? 'modal-xl'); ?>">
        <div class="modal-content">
            <div class="modal-header">
                <?php if($withTitle): ?>
                <h1 class="modal-title fs-5" id="mcLabel"><?php echo e($title??''); ?></h1>
                <button type="button" class="btn-close cancelButton" data-bs-dismiss="modal" aria-label="Close"></button>
                <?php else: ?>
                <button type="button" class="btn-close cancelButton" data-bs-dismiss="modal" aria-label="Close"></button>
                <?php endif; ?>
            </div>
            <div class="modal-body" id="mcbody">
            </div>
            <?php if($withButtons): ?>
            <div class="modal-footer">
                <?php if($cancelbutton??false): ?>
                <button type="button" class="btn btn-secondary btn-sm cancelButton" data-bs-dismiss="modal"><?php echo e($mcTextCancelButton??''); ?></button>
                <?php endif; ?>
                <?php if($aceptbutton??false): ?>
                <button type="button" class="btn <?php echo e($btnColor ?? 'btn-primary'); ?> btn-sm" id="mcButtonText"><?php echo e($mcTextButton??''); ?></button>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\sigciar\resources\views/components/private/modal.blade.php ENDPATH**/ ?>