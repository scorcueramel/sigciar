<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" prefix="og: https://ogp.me/ns#">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldPushContent('title'); ?> | <?php echo e(config('app.name', 'Laravel')); ?></title>

    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.png')); ?>" type="image/png" sizes="192x192">

    <meta property="og:locale" content="es_ES" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="CIAR" />
    <meta property="og:description" content="Centro Internacional de Alto Rendimiento" />
    <meta property="og:url" content="" />
    <meta property="og:site_name" content="CIAR" />

    <meta property="og:image" content="-1200x630.png" />
    <meta property="og:image:secure_url" content="-1200x630.png" />
    <meta property="og:image:width" content="1200" />
    <meta property="og:image:height" content="630" />
    <meta property="og:image:alt" content="CIAR" />

    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:description" content="Centro Internacional de Alto Rendimiento" />
    <meta name="twitter:title" content="CIAR" />
    <meta name="twitter:image" content="-1200x630.png" />

    <meta property="og:image" content="-300x300.png" />
    <meta property="og:image:secure_url" content="-300x300.png" />
    <meta property="og:image:type" content="image/png" />
    <meta property="og:image:width" content="300" />
    <meta property="og:image:height" content="300" />

    <link rel="stylesheet" href="<?php echo e(asset('assets/landing/css/carlos.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/landing/css/styles.css')); ?>">

    <?php echo $__env->yieldPushContent('css'); ?>

</head>

<body>
    <div id="app">
        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        
        <script src="<?php echo e(asset('assets/js/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/landing/libs/swiper/swiper-bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/landing/libs/aos/aos.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/landing/js/main.js?v=205')); ?>"></script>
        <?php echo $__env->yieldPushContent('js'); ?>
    </div>
</body>

</html>
<?php /**PATH C:\laragon\www\sigciar\resources\views/layouts/public/landing.blade.php ENDPATH**/ ?>