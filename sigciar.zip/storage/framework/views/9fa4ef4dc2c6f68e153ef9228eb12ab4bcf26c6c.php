<div class="buy-now">
    <a href="#" target="_blank"
        class="btn btn-danger btn-buy-now">Custom button</a>
</div>
<?php /**PATH C:\laragon\www\sigciar\resources\views/components/private/custom-button.blade.php ENDPATH**/ ?>