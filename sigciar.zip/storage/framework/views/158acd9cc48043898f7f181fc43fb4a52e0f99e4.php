<?php $__env->startPush('title', 'Editar Categoría'); ?>
<?php $__env->startPush('css'); ?>
<style>
    input[type=checkbox] {
        font-size: 20px !important;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Categorías /</span> Editar </h4>
<!-- Basic Layout & Basic with Icons -->
<div class="row mb-3">
    <!-- Basic with Icons -->
    <div class="col-xxl">
        <div class="card mb-4">
            <div class="card-header d-flex align-items-center justify-content-between">
                <h5 class="mb-0">Formulario de edición</h5>
                <small class="text-muted float-end">Editar Categoría</small>
            </div>
            <div class="card-body">
                <form method="post" action="<?php echo e(route('categorias.update',$categoria->id)); ?>" enctype="multipart/form-data" class="row g-3 needs-validation" novalidate>
                    <?php echo csrf_field(); ?>
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="nombre">Nombre</label>
                        <div class="col-sm-10">
                            <div class="input-group input-group-merge">
                                <span id="nombre2" class="input-group-text"><i class="fa-regular fa-layer-group"></i></span>
                                <input type="text" id="nombre" class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Nombre para la categoría" aria-label="Nombre para la sede" aria-describedby="nombre2" name="nombre" value="<?php echo e(old('nombre') ?? $categoria->nombre); ?>" maxlength="100" autofocus required />
                                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 form-label" for="slug">Slug</label>
                        <div class="col-sm-10">
                            <div class="input-group input-group-merge">
                                <span id="message2" class="input-group-text"><i class="fa-brands fa-letterboxd"></i></span>
                                <input type="text" id="slug" class="form-control <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Slug de la categoría" aria-label="Slug de la categoría" aria-describedby="slug2" name="slug" value="<?php echo e(old('slug') ?? $categoria->slug); ?>" maxlength="150" autofocus required readonly />
                                <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 form-label" for="publicado">Estado</label>
                        <div class="col-sm-10">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="estado" id="publciado" value="A" <?php echo e($categoria->estado == 'A' ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="publciado">Públicado</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="estado" id="despublicado" value="I" <?php echo e($categoria->estado == 'I' ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="despublicado">Borrador</label>
                            </div>
                            <div class="form-text">
                                Inidica el estado inicial para la nueva categoría
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-end">
                        <div class="col-sm-8">
                            <button type="submit" class="btn btn-primary">Guardar</button>
                        </div>
                        <div class="col-sm-2 text-end">
                            <a href="<?php echo e(route('categorias.index')); ?>" class="btn btn-danger">Cancelar</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
    $("#nombre").on('keyup', function() {
        var str = $(this).val();
        str = str.replace(/\s+/g, '-').toLowerCase();
        $('#slug').val(str);
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.private.private', ['activePage' => 'categorias.edit'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sigciar\resources\views/pages/private/categorias/edit.blade.php ENDPATH**/ ?>