<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldPushContent('title'); ?> | <?php echo e(config('app.name', 'Laravel')); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.png')); ?>" type="image/x-icon">
    <!-- Fonts -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/global/fonts.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/fontawesome/all.min.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/global/style.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/fullcalendar/main.min.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/select2/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/select2/select2-bootstrap-5-theme.min.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/personalized/style.css')); ?>">

    <?php echo $__env->yieldPushContent('css'); ?>

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
</head>

<body>
    <div id="app">
        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        
        <script src="<?php echo e(asset('assets/js/jquery/jquery.min.js')); ?>"></script>
        
        <script src="<?php echo e(asset('assets/js/fontawesome/all.min.js')); ?>"></script>
        
        <script src="<?php echo e(asset('assets/js/fullcalendar/moment-with-locales.min.js')); ?>"></script>
        
        <script src="<?php echo e(asset('assets/js/fullcalendar/main.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/fullcalendar/locales-all.min.js')); ?>"></script>
        
        <script src="<?php echo e(asset('assets/js/sweetalert/sweetalert2@11.js')); ?>"></script>
        
        <script src="<?php echo e(asset('assets/js/select2/select2.min.js')); ?>"></script>
        
        <script src="<?php echo e(asset('assets/js/personalized/reservation.js')); ?>" type="module"></script>

        <script>
            $(document).ready(function() {
                $(function() {
                    $('[data-toggle="tooltip"]').tooltip()
                })
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
            });
        </script>

        <?php echo $__env->yieldPushContent('js'); ?>
    </div>
</body>

</html>
<?php /**PATH C:\laragon\www\sigciar\resources\views/layouts/public/public.blade.php ENDPATH**/ ?>