<?php $__env->startPush('title', 'Detalle Actividad'); ?>
<?php $__env->startPush('css'); ?>
    <style>
        #regiration_form fieldset:not(:first-of-type) {
            display: none;
        }

        .btn-add {
            font-size: 20px !important;
            border-radius: 50%;
            height: 35px;
        }

        #imagenSeleccionada {
            border-radius: 20px;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Tenis /</span> Detalle </h4>
    <!-- Basic Layout & Basic with Icons -->

    <div class="row mb-3">
        <!-- Basic with Icons -->
        <div class="col-xxl">
            <div class="card mb-4">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <h5 class="mb-0">Detalle de actividad</h5>
                </div>
                <div class="card-body mt-3">
                    <div class="container">
                        <div class="progress mb-3">
                            <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuemin="0"
                                 aria-valuemax="100">
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.private.private', ['activePage' => 'show.actividad'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sigciar\resources\views/pages/private/actividades/tenis/show.blade.php ENDPATH**/ ?>