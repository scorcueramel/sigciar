<?php $__env->startPush('title','Iniciar Sesión'); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <img src="<?php echo e(asset('assets/auth/images/undraw_remotely_2j6y.svg')); ?>" alt="Image" class="img-fluid">
            </div>
            <div class="col-md-6 contents">
                <div class="row justify-content-center">
                    <div class="col-md-8">
                        <div class="mb-4">
                            <h3>Iniciar Sesión</h3>
                            <p class="mb-4">Lorem ipsum dolor sit amet elit. Sapiente sit aut eos consectetur adipisicing.</p>
                        </div>
                        <?php if(Session::has('warning')): ?>

                        <div class="col-md-12">
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <strong>Lo sentimos!</strong> <?php echo e(Session::get('warning')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        </div>
                        <?php endif; ?>
                        <form action="<?php echo e(route('login')); ?>" method="post" autocomplete="off" id="login">
                            <?php echo csrf_field(); ?>
                            <div class="form-group first">
                                <label for="username">Correo</label>
                                <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="username" name="email" value="<?php echo e(old('email')); ?>" autocomplete="off" autofill="off" autofocus required>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    Tu correo no esta registro / mal escrito
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group last mb-4">
                                <label for="password">Contraseña</label>
                                <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" name="password" required autocomplete="off" autofill="off" autocomplete="current-passwprd">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    Error con tu contraseña
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="d-flex mb-5 align-items-center">
                                <label class="control control--checkbox mb-0"><span class="caption"><?php echo e(__('Recordar')); ?></span>
                                    <input type="checkbox" checked="checked" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?> />
                                    <div class="control__indicator"></div>
                                </label>
                                <span class="ml-auto">
                                    <?php if(Route::has('password.request')): ?>
                                    <a href="<?php echo e(route('password.request')); ?>" class="forgot-pass"><?php echo e(__('Forgot Your Password?')); ?></a>
                                    <?php endif; ?>
                                </span>
                            </div>

                            <input type="submit" value="Log In" class="btn btn-block btn-primary">

                            <div class="text-white">
                                <span class="d-block text-left my-4 text-muted">&mdash; or &mdash;</span>
                                <a href="<?php echo e(route('registro.cliente')); ?>" class="btn btn-block btn-primary pt-3 text-decoration-none text-light">
                                    Registrate
                                </a>
                            </div>
                        </form>
                    </div>
                </div>

            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
    $('#login').submit(function() {
        Swal.fire({
            icon: 'info',
            html: "Espere un momento porfavor ...",
            timerProgressBar: true,
            didOpen: () => {
                Swal.showLoading();
            }
        })
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.public.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sigciar\resources\views/auth/login.blade.php ENDPATH**/ ?>