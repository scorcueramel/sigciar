<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="light-style layout-menu-fixed" dir="ltr" data-theme="theme-default" data-assets-path="../assets/" data-template="vertical-menu-template-free">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldPushContent('title'); ?> | <?php echo e(config('app.name', 'Laravel')); ?></title>

    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet" />
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/template/fonts/boxicons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/fontawesome/all.min.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/template/css/core.css')); ?>" class="template-customizer-core-css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/template/css/theme-default.css')); ?>" class="template-customizer-theme-css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/template/css/demo.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/template/css/perfect-scrollbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/template/css/apex-charts.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/fullcalendar/main.min.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/select2/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/select2/select2-bootstrap-5-theme.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/global/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/template/css/datatables/dataTables.bootstrap5.css')); ?>">

    <link href="https://cdn.datatables.net/responsive/3.0.2/css/responsive.bootstrap5.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">


    <?php echo $__env->yieldPushContent('css'); ?>

    <script src="<?php echo e(asset('assets/template/js/helpers.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/template/js/config.js')); ?>"></script>
</head>

<body>
    <div id="app">
        <!-- Layout wrapper -->
        <div class="layout-wrapper layout-content-navbar">
            <div class="layout-container">
                <?php echo $__env->make('components.private.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="layout-page">
                    <?php echo $__env->make('components.private.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- Content wrapper -->
                    <div class="content-wrapper">
                        <!-- Content -->
                        <div class="container-xxl flex-grow-1 container-p-y">
                            <?php echo $__env->yieldContent('content'); ?>
                        </div>
                    </div>
                    <!-- / Content -->
                    <?php echo $__env->make('components.private.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
        </div>
        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- <?php echo $__env->make('components.private.custom-button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->

    
    <script src="<?php echo e(asset('assets/js/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/template/js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/template/js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/template/js/perfect-scrollbar.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/template/js/menu.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/template/js/apexcharts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/template/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/template/js/dashboards-analytics.js')); ?>"></script>
    
    
    <script src="<?php echo e(asset('assets/js/fullcalendar/moment-with-locales.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('assets/js/fullcalendar/main.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/fullcalendar/locales-all.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('assets/js/fullcalendar/moment-with-locales.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('assets/js/fullcalendar/main.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/fullcalendar/locales-all.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('assets/js/sweetalert/sweetalert2@11.js')); ?>"></script>
    
    <script src="<?php echo e(asset('assets/js/select2/select2.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('assets/template/js/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/template/js/datatables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/template/js/datatables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/template/js/datatables/dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/template/js/datatables/dataTables.bootstrap5.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/template/js/datatables/dataTables.responsive.js')); ?>"></script>

    
    <script>
        $(document).ready(function() {
            $(function() {
                $('[data-toggle="tooltip"]').tooltip()
            })
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        (() => {
            'use strict'

            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            const forms = document.querySelectorAll('.needs-validation')

            // Loop over them and prevent submission
            Array.from(forms).forEach(form => {
                form.addEventListener('submit', event => {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }

                    form.classList.add('was-validated')
                }, false)
            })
        })()
    </script>
    <?php echo $__env->yieldPushContent('js'); ?>
</body>

</html>
<?php /**PATH C:\laragon\www\sigciar\resources\views/layouts/private/private.blade.php ENDPATH**/ ?>