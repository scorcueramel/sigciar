<?php if(session()->has('error')): ?>
<?php echo e(session()->get('error')); ?>

<?php elseif(session()->has('warning')): ?>
<?php echo e(session()->get('warning')); ?>

<?php elseif(session()->has('success')): ?>
<?php echo e(session()->get('success')); ?>

<?php endif; ?>
<?php /**PATH C:\laragon\www\sigciar\resources\views/components/private/messages-session.blade.php ENDPATH**/ ?>