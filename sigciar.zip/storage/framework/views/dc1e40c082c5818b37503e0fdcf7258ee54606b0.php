<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldPushContent('title'); ?> | <?php echo e(config('app.name', 'Laravel')); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.png')); ?>" type="image/x-icon">
    <!-- Fonts -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/global/fonts.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/auth/fonts/iconmoon/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/auth/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/auth/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/auth/css/style.css')); ?>">
</head>

<body>
    <div id="app">
        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <script src="<?php echo e(asset('assets/auth/js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/auth/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/auth/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/auth/js/main.js')); ?>"></script>
    
    <script src="<?php echo e(asset('assets/js/sweetalert/sweetalert2@11.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('js'); ?>
</body>

</html>
<?php /**PATH C:\laragon\www\sigciar\resources\views/layouts/public/auth.blade.php ENDPATH**/ ?>