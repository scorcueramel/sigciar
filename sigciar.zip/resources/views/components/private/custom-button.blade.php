<div class="buy-now">
    <a href="#" target="_blank"
        class="btn btn-danger btn-buy-now">Custom button</a>
</div>
