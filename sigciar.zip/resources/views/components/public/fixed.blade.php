<section class="fijados">
	<div class="whatsapp">
		<a class="static-wsp" href="https://wa.me/51977505569?text=Hola!%20Escribo%20desde%20el%20sitio%20web%20de%20CIAR%20y%20quisiera%20m%C3%A1s%20informaci%C3%B3n%20acerca%20de%20sus%20actividades" target="_blank">
			<img src="{{asset('assets/images/ic-whatsapp.svg')}}" />
		</a>
	</div>
</section>
